from __future__ import annotations
import argparse
import os
from dotenv import load_dotenv
from dq_engine.pipeline import run

def main() -> None:
    load_dotenv()

    parser = argparse.ArgumentParser(prog="dq")
    sub = parser.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("run", help="Run dbt + DQ checks, write results to warehouse")
    r.add_argument("--config", required=True)
    r.add_argument("--skip-dbt", action="store_true")
    r.add_argument("--run-dir", default=os.environ.get("DQ_RUN_DIR", ""))

    args = parser.parse_args()
    run_dir = args.run_dir.strip() or None
    run_id = run(args.config, skip_dbt=args.skip_dbt, run_dir=run_dir)
    print(run_id)
